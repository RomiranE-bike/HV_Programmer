/*
 * HV-programmer-ver.0.c
 *
 * Created: 9/20/2023 20:14:41
 * Author : me
 */ 


//-------------------------------------------------------------------------------

/*
#define  DATA    PORTD // PORTD = Arduino Digital pins 0-7
#define  DATAD   DDRD  // Data direction register for DATA port
#define  VCC      8		PB0
#define  RDY     12     PB4 // RDY/!BSY signal from target
#define  OE      11		PB3
#define  WR      10		PB2
#define  BS1      9		PB1
#define  XA0     13		PB5
#define  XA1     18    	PC4	// Analog inputs 0-5 can be addressed as
#define  PAGEL   19    	PC5	// digital outputs 14-19
#define  RST     14    	PC0	// Output to level shifter for !RESET
#define  BS2     16		PC2
#define  XTAL1   17		PC3

#define  BUTTON  15    	PC1	// Run button
#define  LED      0
*/
//-------------------------------------------------------------------------------
/*
#define  data    PORTB // PORTB 0-7 (14,15,16,17,18,19,9,10)
#define  reg     DDRB  // Data direction register for DATA port

#define  RDY     23     PC0     // RDY/!BSY signal from target
#define  OE       4		PD2
#define  WR       6		PD4
#define  BS1     24		PC1
#define  XA0     25		PC2
#define  XA1     26    	PC3	    
#define  PAG     28    	PC5	    
#define  BS2     12		PD6
#define  XTAL1    5		PD3

#define  Reset+12V   13    	PD7	  //output to level shifter for !RESET
#define  VCC+5       11		PD5   //output
#define  ERASE       27		PC4   //input
#define  BUTTON       1    	PC6	  // Run button    /input
#define  RED         25    	PC2	  // RED LED       /output
#define  GREEN       26    	PC3	  // GREEN LED     /output
#define  BUZ          2    	PD0	  // BUZZER        /output

*/


//-------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>

//-------------------------------------------------------------------------------
//#define	HFUSE	0xDF	// Default for ATmega48/88/168, for others see
//#define	LFUSE	0x62	// http://www.engbedded.com/cgi-bin/fc.cgi
#define	HFUSE	0xD9	// Default for ATmega8
#define	LFUSE	0xE1    // Default for ATmega8

//#define	HFUSE	0x99	// Default for ATmega16/32
//#define	LFUSE	0xE1    // Default for ATmega16/32


//-------------------------------------------------------------------------------

//#define  data    PORTB // PORTB 0-7 (14,15,16,17,18,19,9,10)
//#define  reg     DDRB  // Data direction register for DATA port

#define  _RDY      (1<<0)  //23     PC0     //input with pull-up  / RDY/!BSY signal from target
#define  _BS1      (1<<1)  //24		PC1
#define  _XA0      (1<<2)  //25		PC2
#define  _XA1      (1<<3)  //26    	PC3
#define  _PAG      (1<<5)  //28    	PC5

#define  _OE       (1<<2)  // 4		PD2
#define  _WR       (1<<4)  // 6		PD4
#define  _BS2      (1<<6)  //12		PD6
#define  _XTAL1    (1<<3)  // 5		PD3

#define  _RED      (1<<2)  //25  	PC2	  // RED LED       
#define  _GREEN    (1<<3)  //26   	PC3	  // GREEN LED     
#define  _ERASE    (1<<4)  //27	    PC4   // input with pull-up /JUMPER TO GND 
#define  _BUTTON   (1<<6)  // 1   	PC6	  // input with pull-up /Run button    

#define  _BUZ      (1<<0)  // 2   	PD0	  // BUZZER        
#define  _VCC5     (1<<5)  //11	    PD5   // low level for +5 !volt
#define  _Reset12V (1<<7)  //13   	PD7	  // low level for !RESET
//-------------------------------------------------------------------------------
void HardwareInit()
{
	DDRC	= ~(_RDY | _ERASE | _BUTTON);                     // all outputs except (PC0 ,PC4,PC6)
	PORTC	=  (_BUTTON)|(_ERASE);                            // pull-up
	
	DDRD    = 0xff;                                           // all outputs
	PORTD   = (_Reset12V)|(_VCC5)|(_RED)|(_GREEN)|(_BUZ);	          //  RESET12V and _VCC5 off(PD7 = 1,PD5 = 1)

	DDRB	= 0xff;				                              // all outputs
	PORTB	= 0x00;
}
//-------------------------------------------------------------------------------
void sendcmd(unsigned char command)
{
	PORTC |= _XA1;
	PORTC &= ~(_XA0|_BS1);
	
	PORTB = command;

	PORTD |= _XTAL1;
	_delay_ms(1);
	PORTD &= ~(_XTAL1);
	_delay_ms(1);
}
//-------------------------------------------------------------------------------
void writefuse(unsigned char fuse, char highbyte)
{
	PORTC &= ~(_XA1);
	PORTC |= _XA0;
	_delay_ms(1);

	PORTB = fuse;
	PORTD |= _XTAL1;
	_delay_ms(1);
	PORTD &= ~(_XTAL1);

	if (highbyte)
	PORTC |= _BS1;
	else
	PORTC &= ~(_BS1);

	PORTD &= ~(_WR);
	_delay_ms(1);
	PORTD |= _WR;
	_delay_ms(100);
}
//-------------------------------------------------------------------------------
void blink(unsigned char LED)
{

	while (_BUTTON)              // Loop  // wait for button
	{
        
		PORTD |= LED ;           // Toggle LED
		_delay_ms(100);          // Delay
		PORTD &= ~(LED);         // Toggle LED
		_delay_ms(100);          // Delay

	};

}

//---------------------------------------------------------------------------------------------------

void beep(void)                   // Beeping routine
{
	int i;		
	for(i=0;i<1000;i++)          // Loop
	{
		
		PORTD |= _BUZ;           // Toggle LED
		_delay_us(100);          // Delay
		PORTD &= ~(_BUZ);        // Toggle LED
		_delay_us(100);          // Delay
	};

}

//---------------------------------------------------------------------------------------------------
void alert(void)
{
	beep();
	_delay_ms(1000);
	beep();
	_delay_ms(1000);
}
//-------------------------------------------------------------------------------
int main()
{
	HardwareInit();
	alert();
	blink(_RED);

	for (;;)
	{
		while (PINC & _BUTTON) {}	// wait for button

		// Initialize pins to enter programming mode
		PORTC &= ~(_PAG|_XA1);
		PORTD &= ~(_BS2);
		PORTC &= ~(_XA0|_BS1);
		
		
		// Enter programming mode
		PORTD &= ~(_VCC5);
		PORTD |= _WR|_OE;
		_delay_ms(1);
		PORTD &= ~(_Reset12V);
		_delay_ms(1);

		// Program HFUSE
		sendcmd(0b01000000);
		writefuse(HFUSE, 1);

		// Program LFUSE
		sendcmd(0b01000000);
		writefuse(LFUSE, 0);

		_delay_ms(1000);			// allow button to be released

		// Exit programming mode
		PORTD |= _Reset12V;

		// Turn off outputs
		PORTB = 0x00;
		PORTD &= ~(_OE|_BS2|_WR|_VCC5);
		PORTC &= ~(_BS1|_XA0|_XA1|_PAG);
		beep();
		blink(_GREEN);
	}
}

//-------------------------------------------------------------------------------
/*
 * HV_Programmer_ver.4_1404.c
 *
 * Created: 5/11/2025 21:53:13
 * Author : me
 */ 

#include <avr/io.h>
#include <util/delay.h>

//-------------------------------------------------------------------------------
// Fuse settings for ATtiny26
#define  HFUSE    0x64    // Default high fuse for ATtiny26
#define  LFUSE    0xDF    // Default low fuse for ATtiny26

// ATtiny26 Signature Bytes
#define SIG1 0x1E        // Signature byte 1
#define SIG2 0x91        // Signature byte 2
#define SIG3 0x0F        // Signature byte 3

//-------------------------------------------------------------------------------
// Port Definitions
#define  data       PORTB    // PORTB used for data bus (PB0-PB7)
#define  reg        DDRB     // Data direction register for PORTB

// PORTD Definitions
#define  LED        PORTD0   // LED indicator
#define  BUZ        PORTD1   // Buzzer
#define  OE         PORTD2   // Output Enable
#define  XTAL1      PORTD3   // XTAL1 pin
#define  WR         PORTD4   // Write pulse
#define  VCC        PORTD5   // +5V control (0=on, 1=off via PNP transistor)
#define  BS2        PORTD6   // BS2 control
#define  Reset12V   PORTD7   // +12V reset control (1=on, 0=off)

// PORTC Definitions
#define  RDY        PINC0    // Ready/Busy input (with pull-up)
#define  BS1        PORTC1   // BS1 control
#define  XA0        PORTC2   // XA0 control
#define  XA1        PORTC3   // XA1 control
#define  BUTTON     PINC4    // Start button input (with pull-up)
#define  PAG        PORTC5   // PAGEL control

//-------------------------------------------------------------------------------
// Function Prototypes
void settingPorts(void);            // Initialize ports
void enterProgMode(void);           // Enter programming mode
void exitProg(void);                // Exit programming mode
void sendCommand(unsigned char cmd); // Send command to target
void eraseChip(void);               // Perform chip erase
void setHfuse(unsigned char fuse);   // Program high fuse
void setLfuse(unsigned char fuse);   // Program low fuse
void setLock(void);                 // Program lock bits
void setExtendedFuse(void);         // Program extended fuse
void cmdDown(void);                 // Visual/audio command indicator
void beep(void);                    // Sound buzzer
void readSignature(void);           // Read device signature
void repairSignature(void);         // Repair corrupted signature bytes
void verifySignature(void);         // Verify signature against known values

void XTALPulse(void);              // Generate XTAL pulse
void WRPulse(void);                // Generate WR pulse

// Timing constants
#define  HIGH  1
#define  LOW   0
#define dS  500     // Stable delay (250ms)
#define dP  150      // Pulse delay (50ms)

// Global variables for signature storage
unsigned char sig1, sig2, sig3;
unsigned char sig_correct = 0; // Flag for correct signature

//-------------------------------------------------------------------------------
int main(void)
{
	settingPorts(); // Initialize hardware

	while (1)
	{
		// Wait for button press to start programming
		//beep();
		
		if(!(PINC & (1 << BUTTON))) // Button pressed
		{
			cmdDown(); // Visual/audio feedback
			
			// 1. Enter programming mode
			enterProgMode();
			cmdDown();
			_delay_ms(dS);
			
			// 2. Read and verify signature
			readSignature();
			cmdDown();
			_delay_ms(dS);
			
			// 3. If signature is wrong, attempt repair
			if(!sig_correct)
			{
				repairSignature();
				cmdDown();
				_delay_ms(dS);
				
				// Verify repair
				readSignature();
				cmdDown();
				_delay_ms(dS);
			}
			
			// 4. Continue with normal programming if signature is correct
			if(sig_correct)
			{
				// Program lock bits
				sendCommand(0x20);
				setLock();
				cmdDown();
				_delay_ms(dS);
				
				// Program high fuse
				sendCommand(0x40);
				setHfuse(HFUSE);
				cmdDown();
				_delay_ms(dS);
				
				// Program low fuse
				sendCommand(0x40);
				setLfuse(LFUSE);
				cmdDown();
				_delay_ms(dS);
				
				// Program extended fuse
				sendCommand(0x40);
				setExtendedFuse();
				cmdDown();
				_delay_ms(dS);
				
				// Erase chip
				sendCommand(0x80);
				eraseChip();
				cmdDown();
				_delay_ms(dS);
			}
			
			// Exit programming mode
			exitProg();
			cmdDown();
		}
		else
		{
			// Idle state
			_delay_ms(dS);
			PORTD &= ~(1 << LED); // LED off
			PORTC |= (1 << XA1); // XA1 high
		}
	}
}

//-------------------------------------------------------------------------------
// Initialize all ports and set default states
void settingPorts(void)
{
	// PORTD - all outputs
	DDRD = 0xFF;
	PORTD = 0x00;
	PORTD |= (1 << VCC);       // Turn off +5V initially
	PORTD &= ~(1 << Reset12V); // Turn off +12V initially

	// PORTB - data bus (all outputs)
	DDRB = 0xFF;
	PORTB = 0x00;

	// PORTC configuration:
	// PC0 (RDY) and PC4 (BUTTON) as inputs with pull-up
	// All others as outputs
	DDRC = 0xEE;     // 0b11101110
	PORTC = 0x11;    // Enable pull-ups on PC0 and PC4
}

//-------------------------------------------------------------------------------
// Enter programming mode sequence
void enterProgMode(void)
{
	// Initial state
	PORTC = 0x19;
	PORTD = 0x23;
	PORTB = 0x00;
	_delay_ms(dS);
	
	// Apply programming voltage sequence
	PORTD = 0x14;
	_delay_ms(dP);
	
	// Activate target
	PORTD = 0x94;
	_delay_ms(dP);
}

//-------------------------------------------------------------------------------
// Send command to target device
void sendCommand(unsigned char cmd)
{
	PORTC = 0x19;       // Set control lines
	PORTD = 0x96;       // Set programming lines
	PORTB = cmd;        // Put command on data bus
	XTALPulse();        // Clock the command in
}

//-------------------------------------------------------------------------------
// Read all three signature bytes and verify against known values
void readSignature(void)
{
	// Read signature byte 0 (should be 0x1E)
	sendCommand(0x08);  // Command to read signature byte 0
	PORTC = 0x09;       // Prepare to read
	PORTD = 0x94;
	_delay_ms(dP);
	sig1 = PINB;        // Read the signature byte
	
	// Read signature byte 1 (should be 0x91)
	sendCommand(0x08 + 0x01);  // Command to read signature byte 1
	PORTC = 0x09;
	PORTD = 0x94;
	_delay_ms(dP);
	sig2 = PINB;
	
	// Read signature byte 2 (should be 0x0F)
	sendCommand(0x08 + 0x02);  // Command to read signature byte 2
	PORTC = 0x09;
	PORTD = 0x94;
	_delay_ms(dP);
	sig3 = PINB;
	
	// Verify signature
	verifySignature();
}

//-------------------------------------------------------------------------------
// Verify read signature against known ATtiny26 values
void verifySignature(void)
{
	if((sig1 == SIG1) && (sig2 == SIG2) && (sig3 == SIG3))
	{
		sig_correct = 1; // Signature matches
		// Blink LED quickly to indicate good signature
		for(int i=0; i<3; i++)
		{
			PORTD |= (1 << LED);
			_delay_ms(100);
			PORTD &= ~(1 << LED);
			_delay_ms(100);
		}
	}
	else
	{
		sig_correct = 0; // Signature doesn't match
		// Sound long beep to indicate bad signature
		for(int i=0; i<3; i++)
		{
			beep();
			_delay_ms(200);
		}
	}
}

//-------------------------------------------------------------------------------
// Attempt to repair corrupted signature bytes
void repairSignature(void)
{
	// Signature repair sequence for ATtiny26
	
	// 1. Enter signature calibration mode (vendor specific)
	sendCommand(0xAC);
	sendCommand(0x5E);
	sendCommand(0x08);
	sendCommand(SIG1); // Write correct signature byte 1
	
	// Pulse WR to write the byte
	PORTC = 0x15;
	WRPulse();
	
	// 2. Write second signature byte
	sendCommand(0xAC);
	sendCommand(0x5E);
	sendCommand(0x09);
	sendCommand(SIG2); // Write correct signature byte 2
	PORTC = 0x15;
	WRPulse();
	
	// 3. Write third signature byte
	sendCommand(0xAC);
	sendCommand(0x5E);
	sendCommand(0x0A);
	sendCommand(SIG3); // Write correct signature byte 3
	PORTC = 0x15;
	WRPulse();
	
	// 4. Exit signature calibration mode
	sendCommand(0xAC);
	sendCommand(0x5F);
	sendCommand(0x00);
	PORTC = 0x15;
	WRPulse();
	
	// Note: This sequence is chip-specific and may need adjustment
	// for different AVR models or programming hardware
}

//-------------------------------------------------------------------------------
// Program high fuse
void setHfuse(unsigned char fuse)
{
	PORTC = 0x15;       // Set control lines for fuse programming
	_delay_ms(dP);
	PORTB = fuse;       // Put fuse value on data bus
	XTALPulse();        // Clock the data in
	PORTC = 0x17;       // Set control lines for write
	WRPulse();          // Pulse WR to program fuse
}

//-------------------------------------------------------------------------------
// Program low fuse
void setLfuse(unsigned char fuse)
{
	PORTC = 0x15;
	_delay_ms(dP);
	PORTB = fuse;
	XTALPulse();
	PORTC = 0x15;
	WRPulse();
}

//-------------------------------------------------------------------------------
// Program lock bits
void setLock(void)
{
	PORTC = 0x15;
	_delay_ms(dP);
	PORTB = 0xFF;       // Typical value for no lock
	XTALPulse();
	PORTC = 0x15;
	WRPulse();
}

//-------------------------------------------------------------------------------
// Program extended fuse
void setExtendedFuse(void)
{
	PORTC = 0x15;
	_delay_ms(dP);
	PORTB = 0xFF;       // Typical value for ATtiny26
	XTALPulse();
	PORTC = 0x15;
	PORTD = 0xC4;       // Special control for extended fuse
	WRPulse();
}

//-------------------------------------------------------------------------------
// Perform chip erase
void eraseChip(void)
{
	PORTC = 0x15;
	WRPulse();
}

//-------------------------------------------------------------------------------
// Exit programming mode
void exitProg(void)
{
	// Return all lines to idle state
	PORTC = 0x11;
	PORTD = 0x23;
	PORTB = 0x00;
	beep();
}

//-------------------------------------------------------------------------------
// Visual/audio feedback for command execution
void cmdDown(void)
{
	beep();
	PORTD |= (1 << LED); // LED on
	_delay_ms(dP);
	PORTD &= ~(1 << LED); // LED off
	_delay_ms(dP);
}

//-------------------------------------------------------------------------------
// Generate XTAL pulse for clocking data
void XTALPulse(void)
{
	PORTD = 0x9D; // XTAL high
	_delay_ms(dP);
	PORTD = 0x94; // XTAL low
	_delay_ms(dP);
}

//-------------------------------------------------------------------------------
// Generate WR pulse for programming operations
void WRPulse(void)
{
	PORTD = 0x84; // WR low (active)
	_delay_ms(dP);
	PORTD = 0x94; // WR high
	_delay_ms(dP);
}

//-------------------------------------------------------------------------------
// Sound the buzzer
void beep(void)
{
	for(int i = 0; i < 500; i++)
	{
		PORTD |= (1 << BUZ);
		_delay_us(500);
		PORTD &= ~(1 << BUZ);
		_delay_us(500);
	}
}

/*
 * HV_Programmer_ver.3_1404.c
 *
 * Created: 5/11/2025 16:02:20
 * Author : me
 
 
 Device 	Signature	LFUSE	HFUSE	EFUSE	Lock Bits
 
 ATtiny26	1E 91 03	  64	  DF	  N/A	  FF
 ATmega8	1E 93 07	  E1	  D9	  N/A	  FF
 ATmega16	1E 94 03	  E1	  D9	  FF	  FF
 ATmega32	1E 95 02	  E1	  D9	  FF	  FF
 
 # Read signature:
 avrdude -c usbasp -p m8 -v

 # Read fuses:
 avrdude -c usbasp -p m8 -U lfuse:r:-:h -U hfuse:r:-:h -U efuse:r:-:h

 # Reset to factory defaults (ATmega8 example):
 avrdude -c usbasp -p m8 -U lfuse:w:0xe1:m -U hfuse:w:0xd9:m -U lock:w:0xff:m
 
 */ 
//----------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
//----------------------------------------------------------------------------------------------------------

// Status Indicators
#define LED_PWR      PORTD0
#define LED_PROG     PORTD0
#define LED_SUCCESS  PORTD0
#define BUZZER       PORTD1
// ATtiny26 HVPP Control Pins
//#define HVPP_GND   ???
#define HVPP_OE      PORTD2
#define HVPP_XTAL1   PORTD3
#define HVPP_WR      PORTD4
#define HVPP_VCC     PORTD5
#define HVPP_BS2     PORTD6
#define HVPP_RESET   PORTD7
#define HVPP_BS1     PORTC1
#define HVPP_RDY     PINC0

// Start Button
#define BUTTON       PINC4
#define BUTTON_DDR   DDRC
#define BUTTON_PORT  PORTC
#define BUTTON_PIN   PINC

// Default values for attiny26
#define SIG1 0x1E
#define SIG2 0x91
#define SIG3 0x03
#define DEFAULT_LFUSE 0x64
#define DEFAULT_HFUSE 0xDF
#define DEFAULT_LOCK  0xFF

// Button debounce delay (ms)
#define DEBOUNCE_DELAY 50
//----------------------------------------------------------------------------------------------------------
uint8_t is_button_pressed() {
	if(!(BUTTON_PIN & (1<<BUTTON))) { // Button is active-low
		_delay_ms(DEBOUNCE_DELAY);
		if(!(BUTTON_PIN & (1<<BUTTON))) {
			while(!(BUTTON_PIN & (1<<BUTTON))); // Wait for release
			return 1;
		}
	}
	return 0;
}
//----------------------------------------------------------------------------------------------------------
/*
Status Indication Summary:

State	             LEDs	        Buzzer
Power On	         Red solid	    1 beep
Ready (Idle)	     Red blink	    None
Button Pressed	     Ylw+Red	    1 beep
Signature Repair	 Ylw+Grn	    Pulses
Fuse Repair	         All LEDs	    Pulses
Success	             Green solid	4 beeps
Error	             Red+Grn	    3 fast beeps
*/
void indicate(uint8_t pattern, uint8_t beeps) {
	// Visual feedback
	PORTD = (PORTD & 0x1F) | ((pattern & 0x07) << 5);
	
	// Audio feedback
	for(uint8_t i=0; i<beeps; i++) {
		int i;
		for(i=0;i<500;i++){       // Loop
			PORTD |= (1<<BUZZER);              // Toggle BUZZER
			_delay_us(500);         // Delay
			PORTD &= ~(1<<BUZZER);               // Toggle BUZZER
			_delay_us(500);         // Delay
		}		
		if(i < beeps-1) _delay_ms(200);
	}
}
//----------------------------------------------------------------------------------------------------------
void init_hvpp() {
	// Set control pins as outputs
	//DDRD |= (1<<HVPP_GND)
	DDRD |= (1<<HVPP_VCC)|(1<<HVPP_RESET)|(1<<HVPP_XTAL1)|(1<<BUZZER);
	DDRD |= (1<<HVPP_OE)|(1<<HVPP_WR)|(1<<HVPP_BS2)|(1<<LED_PWR)|(1<<LED_PROG)|(1<<LED_SUCCESS);
	DDRC |= (1<<HVPP_BS1);
	
	DDRB = 0xFF; // Data bus as output
	BUTTON_DDR &= ~(1<<BUTTON); // Button as input
	BUTTON_PORT |= (1<<BUTTON); // Enable pull-up
	DDRC  &= ~(1<<HVPP_RDY); //as input
	PORTC |= (1<<HVPP_RDY);  // Enable pull-up
	
	// Initialize states
	PORTD &= ~((1<<HVPP_RESET)|(1<<HVPP_XTAL1)|(1<<BUZZER));
	PORTD |= (1<<HVPP_OE)|(1<<HVPP_WR); // OE and WR inactive high
	
	// Startup indication
	indicate(0b001, 1); // Power LED on
	_delay_ms(500);
}
//----------------------------------------------------------------------------------------------------------
void enter_hvpp_mode() {
	indicate(0b011, 2); // Yellow + Red
	PORTD |= (1<<HVPP_VCC);
	//PORTD |= (1<<HVPP_GND);
	
	// Pulse 12V to RESET
	PORTD |= (1<<HVPP_RESET);
	_delay_ms(100);
	PORTD &= ~(1<<HVPP_RESET);
	
	PORTD |= (1<<HVPP_XTAL1);
	indicate(0b010, 1); // Yellow only
}
//----------------------------------------------------------------------------------------------------------
void write_byte(uint8_t bs1, uint8_t bs2, uint8_t data) {
	// Flash LED during write
	PORTD |= (1<<LED_PROG);
	
	// Set address
	if(bs1) PORTC |= (1<<HVPP_BS1);
	else PORTC &= ~(1<<HVPP_BS1);
	
	if(bs2) PORTD |= (1<<HVPP_BS2);
	else PORTD &= ~(1<<HVPP_BS2);
	
	PORTB = data;
	
	PORTD &= ~(1<<HVPP_WR);
	_delay_us(1);
	PORTD |= (1<<HVPP_WR);
	_delay_us(1);
	
	while(!(PINC & (1<<HVPP_RDY)));
	PORTD &= ~(1<<LED_PROG);
}
//----------------------------------------------------------------------------------------------------------
uint8_t read_byte(uint8_t bs1, uint8_t bs2) {
	// Set address
	if(bs1) PORTC |= (1<<HVPP_BS1);
	else PORTC &= ~(1<<HVPP_BS1);
	
	if(bs2) PORTD |= (1<<HVPP_BS2);
	else PORTD &= ~(1<<HVPP_BS2);
	
	DDRB = 0x00;
	PORTD &= ~(1<<HVPP_OE);
	_delay_us(1);
	uint8_t data = PINC;
	PORTD |= (1<<HVPP_OE);
	
	// Quick blink on read
	PORTD ^= (1<<LED_PROG);
	_delay_us(10);
	PORTD ^= (1<<LED_PROG);
	
	return data;
}
//----------------------------------------------------------------------------------------------------------
uint8_t verify_byte(uint8_t bs1, uint8_t bs2, uint8_t expected) {
	uint8_t read = read_byte(bs1, bs2);
	if(read != expected) {
		indicate(0b101, 3); // Error pattern
		_delay_ms(1000);
		return 0;
	}
	return 1;
}
//----------------------------------------------------------------------------------------------------------
void repair_signature() {
	indicate(0b110, 1); // Yellow + Green
	_delay_ms(200);
	
	write_byte(0, 0, SIG1);
	write_byte(1, 0, SIG2);
	write_byte(0, 1, SIG3);
	
	// Verification
	if(!verify_byte(0, 0, SIG1)) return;
	if(!verify_byte(1, 0, SIG2)) return;
	if(!verify_byte(0, 1, SIG3)) return;
	
	indicate(0b010, 2); // Success beep
}
//----------------------------------------------------------------------------------------------------------
void repair_fuses() {
	indicate(0b111, 1); // All LEDs
	_delay_ms(200);
	
	write_byte(0, 0, DEFAULT_LFUSE);
	write_byte(1, 0, DEFAULT_HFUSE);
	write_byte(0, 1, DEFAULT_LOCK);
	
	// Verification
	if(!verify_byte(0, 0, DEFAULT_LFUSE)) return;
	if(!verify_byte(1, 0, DEFAULT_HFUSE)) return;
	if(!verify_byte(0, 1, DEFAULT_LOCK)) return;
	
	indicate(0b010, 3); // Success beep
}
//----------------------------------------------------------------------------------------------------------
void run_repair_sequence() {
	// Start repair process
	enter_hvpp_mode();
	
	// Repair sequence with visual feedback
	indicate(0b010, 1); // Programming started
	repair_signature();
	_delay_ms(300);
	
	indicate(0b011, 1); // Fuses started
	repair_fuses();
	_delay_ms(300);
	
	// Final success indication
	indicate(0b100, 4); // Green LED + long beep
	PORTD &= ~((1<<HVPP_VCC)|(1<<HVPP_XTAL1));
}
//----------------------------------------------------------------------------------------------------------
int main(void) {
	init_hvpp();
	
	// Ready state - blink red waiting for button
	indicate(0b001, 0);
	
	while(1) {
		// Wait for button press
		if(is_button_pressed()) {
			// Button pressed - start repair
			indicate(0b011, 1); // Yellow + Red
			_delay_ms(200);
			run_repair_sequence();
		}
		
		// Idle state - blink green
		PORTD ^= (1<<LED_SUCCESS);
		_delay_ms(500);
	}
}
//----------------------------------------------------------------------------------------------------------

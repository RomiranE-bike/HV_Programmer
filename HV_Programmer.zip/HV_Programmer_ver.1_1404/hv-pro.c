/*
 * hv-pro.c
 *
 * Created: 5/10/2025 21:38:42
 * Author: User
 */

/*
 * HV-programmer-ver.1.c
 *
 * Created: 10/3/2023 19:28:00
 * Author : me
 */
//-------------------------------------------------------------------------------
#include <mega8.h>
#include <io.h>
#include <delay.h>

//-------------------------------------------------------------------------------
#define  LFUSE    0xE1    // 0xE1 Default for ATmega8
#define  HFUSE    0xD9    // 0xD9 Default for ATmega8

//#define  LFUSE    0xE1    // 0xE1 Default for ATmega16/32
//#define  HFUSE    0x99    // 0x99 Default for ATmega16/32

//#define  LFUSE    0xF9    // 0xF9 Default for ATtiny26
//#define  HFUSE    0xF7    // 0xF7 Default for ATtiny26



//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
#define  data       PORTB    // PB0-PB7 //ALL OUTPUTS
#define  reg        DDRB


#define  LED        PORTD.0
#define  BUZ        PORTD.1
#define  OE         PORTD.2
#define  XTAL1      PORTD.3
#define  WR         PORTD.4
#define  VCC        PORTD.5    //off=1 & on=0 just pnp transistor
#define  BS2        PORTD.6
#define  Reset12V   PORTD.7   // low level for !RESET   OFF=0 & on=1

#define  RDY        PINC.0    // input with pull-up  / RDY/!BSY signal from target
#define  BS1        PORTC.1
#define  XA0        PORTC.2
#define  XA1        PORTC.3
#define  BUTTON     PINC.4   // input with pull-up /start by press the button
#define  PAG        PORTC.5
//-------------------------------------------------------------------------------
void settingPorts(void);
void enterProgMode(void);
void sendComand(unsigned char cmd);
void erase(void);
void setHfuse(unsigned char fuse);
void setLfuse(unsigned char fuse);
void setLock(void);
void setExtendedFuse(void);
void cmdDown(void);
void exit(void);

void XTALPulse(void);
void WRPulse(void);
void beep(unsigned char duration);



const int  HIGH =1;
const int  LOW  =0;
int dS=250;     // stable delay 500 ms
int dP=50;      // pulse delay 100   ms


//-------------------------------------------------------------------------------
void main(void){

        settingPorts();

            while (1) {
                          // wait for button // PORTC.4 as input   // 0b 0001 1111
                          beep(2);
                          if(BUTTON==LOW){

                                cmdDown();
/*
Enter Programming Mode

1. Apply 4.5 - 5.5V between VCC and GND, and wait at least 100 �s.
2. Set RESET to �0� and toggle XTAL1 at least 6 times
3. Set the Prog_enable pins listed in Table 110 on page 263 to �0000� and wait at least 100ns.
4. Apply 11.5 - 12.5V to RESET. Any activity on Prog_enable pins within 100 ns after +12V
has been applied to RESET, will cause the device to fail entering Programming mode.
*/
                                enterProgMode();  //RDY LED afected "ON" if MCU not Damaged*****
                                cmdDown();
                                delay_ms(dS);     // stable delay


                                /*
Load Command �Chip Erase�
1. Set XA1, XA0 to �10�. This enables command loading.
2. Set BS1 to �0�.
3. Set DATA to �1000 0000�. This is the command for Chip Erase.
4. Give XTAL1 a positive pulse. This loads the command.
5. Give ~WR a negative pulse. This starts the Chip Erase. RDY/~BSY goes low.
6. Wait until RDY/~BSY goes high before loading a new command.
*/
                                sendComand(0x80); //0x80 cmd for  erase chip
                                erase();
                                cmdDown();
                                delay_ms(dS);     // stable delay


                                 /*
Programming the Fuse Low Bits

1. A: Load Command �0100 0000�.
2. C: Load Data Low Byte. Bit n = �0� programs and bit n = �1� erases the Fuse bit.
3. Set BS1 to �0� and BS2 to �0�.
4. Give ~WR a negative pulse and wait for RDY/~BSY to go high.
*/
                                sendComand(0x40); //0x40 cmd for  set L-fuse bits
                                setLfuse(LFUSE);  //set L-fuse bits 0xE1 for atmega 8
                                cmdDown();
                                delay_ms(dS);     // stable delay

/*
Programming the Fuse High Bits

1. A: Load Command �0100 0000�.
2. C: Load Data Low Byte. Bit n = �0� programs and bit n = �1� erases the Fuse bit.
3. Set BS1 to �1� and BS2 to �0�. This selects high data byte.
4. Give ~WR a negative pulse and wait for RDY/~BSY to go high.
5. Set BS1 to �0�. This selects low data byte.
*/
                                sendComand(0x40); //0x40 cmd for  set H-fuse bits
                                setHfuse(HFUSE);  //set H-fuse bits 0xD9 for atmega 8
                                cmdDown();
                                delay_ms(dS);     // stable delay

                                sendComand(0x40); //0x40 cmd for  set ExtendedFuse bits
                                setExtendedFuse();
                                cmdDown();
                                delay_ms(dS);

/*
Programming the Lock Bits

1. A: Load Command �0010 0000�.
2. C: Load Data Low Byte. Bit n = �0� programs the Lock bit.
3. Give ~WR a negative pulse and wait for RDY/~BSY to go high.
The Lock bits can only be cleared by executing Chip Erase.
*/
                                sendComand(0x20); //0x20 cmd for  set lockbits
                                setLock();
                                cmdDown();
                                delay_ms(dS);              // stable delay


                                exit();
                                cmdDown();
                                }

                                    else{
                                         delay_ms(dS);               // stable delay
                                         LED=LOW;
                                         XA1=HIGH;
                                         };

                }
}
//-------------------------------------------------------------------------------
void settingPorts(void){

            DDRD=0xff;      //make port D as output
            PORTD=0x00;     //write data on port D
            VCC=HIGH;       // turn off +5V
            Reset12V=LOW;   // turn off +12V

            reg=0xff;       //make port B as data output
            data=0x00;      //load data on port B

                            //if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
            DDRC=0xee ;     //0b 1110 1110  // all outputs except PC0 and PC4 inputs// (PC0,PC4) //RDY and BUTTON as input
            PORTC=0x11;     // pull-up PC0 and PC4   0b 0001 0001
}
//-------------------------------------------------------------------------------
void enterProgMode(void){
        PORTC=0x11;PORTD=0x23;PORTB=0x00;      //enter prog mode
        delay_ms(dS);                          // stable delay
        PORTD=0x14;
        delay_ms(dP);                         // pulse delay
        PORTD=0x94;                           //target Active
        delay_ms(dP);                         // pulse delay
}
//-------------------------------------------------------------------------------
void sendComand(unsigned char cmd){
        PORTC=0x19;PORTD=0x96;PORTB=cmd;       //if pin xtal1 of AVR Dameged *****?????????
        XTALPulse();
}
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
void setHfuse(unsigned char fuse){
        PORTC=0x15;                           //set H-fuse bits 0xD9 for atmega 8
        delay_ms(dP);                         // pulse delay
        PORTB=fuse;
        XTALPulse();
        PORTC=0x17;
        WRPulse();
}
//-------------------------------------------------------------------------------
void setLfuse(unsigned char fuse){
        PORTC=0x15;                            //set L-fuse bits 0xE1 for atmega 8
        delay_ms(dP);                           // pulse delay
        PORTB=fuse;
        XTALPulse();
        PORTC=0x15;
        WRPulse();
}
//-------------------------------------------------------------------------------
void setLock(){                        //set lockbits
        PORTC=0x15;
        delay_ms(dP);
        PORTB=0xFF;
        XTALPulse();
        PORTC=0x15;
        WRPulse();
}
//-------------------------------------------------------------------------------
void setExtendedFuse(void){                        //set lockbits
        PORTC=0x15;
        delay_ms(dP);
        PORTB=0xFF;
        XTALPulse();
        PORTC=0x15;PORTD=0xC4;
        WRPulse();
}
//-------------------------------------------------------------------------------
void erase(){
        PORTC=0x15;
        WRPulse();

}
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
void exit(void){
      PORTC=0x11;
      PORTD=0x23;
      PORTB=0x00;    //exit
      //delay_ms(dS);                        // stable delay
      beep(3);
}
//-------------------------------------------------------------------------------
void cmdDown(void){
      beep(1);
      LED=HIGH;
      delay_ms(dP);
      LED=LOW;
      delay_ms(dP);
}
//-------------------------------------------------------------------------------
// Give XTAL1 a positive pulse.
void XTALPulse(void){
      PORTD=0x9D;
      delay_ms(dP);                         // pulse delay
      PORTD=0x94;
      delay_ms(dP);                          // pulse dela
}
//-------------------------------------------------------------------------------
// Give WR a negative pulse for Erase target.
void WRPulse(void){
      PORTD=0x84;               //erase chip
      delay_ms(dP);             // pulse delay
      PORTD=0x94;
      delay_ms(dP);
}
//-------------------------------------------------------------------------------
void beep(unsigned char duration)                    // Beeping routine
{
      int d;
      int i;
      for(d=0;d<duration;d++){       // Loop
        for(i=0;i<500;i++){       // Loop
            BUZ=HIGH;              // Toggle BUZZER
            delay_us(50);         // Delay
            BUZ=LOW;               // Toggle BUZZER
            delay_us(50);         // Delay
           };
           if(d<duration-1) delay_ms(50);
           };
}
//-------------------------------------------------------------------------------

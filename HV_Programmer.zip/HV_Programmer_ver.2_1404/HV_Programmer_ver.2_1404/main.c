/*
 * HV_Programmer_ver.2_1404.c
 *
 * Created: 5/10/2025 16:59:37
 * Author : me
 */ 

//-------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>

//-------------------------------------------------------------------------------
//#define  HFUSE    0xD9    // 0xD9 Default for ATmega8
//#define  LFUSE    0xE1    // 0xE1 Default for ATmega8
//#define  HFUSE    0xD9    // 0x99 Default for ATmega16/32
//#define  LFUSE    0xE1    // 0xE1 Default for ATmega16/32
#define  HFUSE    0xF7    // 0xD9 Default for ATtiny26
#define  LFUSE    0xF9    // 0xE1 Default for ATtiny26
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
#define  data       PORTB    // 14-19 ,9,10    // PB0-PB7 //ALL OUTPUTS
#define  reg        DDRB     //

//MASTER     //SLAVE
#define  LED        PD0  // 2                   PC0      // LED
#define  BUZ        PD1  // 3                   PC1      // BUZZER
#define  OE         PD2  // 4          //4      PD0
#define  XTAL1      PD3  // 5          //9      PD
#define  WR         PD4  // 6          //5      PD1
#define  VCC        PD5  // 11                           //off=1 & on=0 just PNP_transistor
#define  BS2        PD6  // 12         //25     PD7
#define  Reset12V   PD7  // 13         //1      PC3      // low level for !RESET   OFF=0 & on=1

#define  RDY        PC0   // 23         //3      PC5      // input with pull-up  / RDY/!BSY signal from target
#define  BS1        PC1  // 24         //6      PD2
#define  XA0        PC2  // 25         //11     PD3
#define  XA1        PC3  // 26         //12     PD4
#define  BUTTON     PC4   // 27                  PC4      // input with pull-up /start by press the button
#define  PAG        PC5  // 28         //13     PD5
//-------------------------------------------------------------------------------
void settingPorts(void);
void enterProgMode(void);
void sendComand(unsigned char cmd);
void erase(void);
void setHfuse(unsigned char fuse);
void setLfuse(unsigned char fuse);
void setLock(void);
void setExtendedFuse(void);
void cmdDown(void);
void exit(void);

void XTALPulse(void);
void WRPulse(void);
void beep(void);


//#define  HIGH  1
//#define  LOW   0
#define  dS 250     // stable delay 500 ms
#define  dP 50      // pulse delay 100   ms


//-------------------------------------------------------------------------------
void main(void){

	settingPorts();


	while (1) {
		// wait for button // PORTC.4 as input   // 0b 0001 1111
		if(PINC &(1<<BUTTON)==0){
			cmdDown();

			enterProgMode();  //RDY LED affected "ON" if MCU not Damaged*****
			cmdDown();
			_delay_ms(dS);     // stable delay

			sendComand(0x20); //0x20 cmd for  set lock_bits
			setLock();        //0XFF set lock_bits
			cmdDown();
			_delay_ms(dS);              // stable delay

			sendComand(0x40); //0x40 cmd for  set H-fuse bits
			setHfuse(HFUSE);  //set H-fuse bits 
			cmdDown();
			_delay_ms(dS);     // stable delay

			sendComand(0x40); //0x40 cmd for  set L-fuse bits
			setLfuse(LFUSE);  //set L-fuse bits 
			cmdDown();
			_delay_ms(dS);     // stable delay

			sendComand(0x40); //0x40 cmd for  set L-fuse bits
			setExtendedFuse();
			cmdDown();
			_delay_ms(dS);

			sendComand(0x80); //0x80 cmd for  erase chip
			erase();
			cmdDown();
			_delay_ms(dS);     // stable delay

			exit();
			cmdDown();
		}

		else{
			_delay_ms(dS);               // stable delay
			PORTD &= ~(1 << LED);
			PORTC |= (1 << XA1);
		};

	}
}
//-------------------------------------------------------------------------------
void settingPorts(void){

	DDRD=0xff;      //make port D as output
	PORTD=0x00;     // set low
	
	PORTD |= (1 <<VCC);       // turn off +5V
	PORTD &= ~(1 <<Reset12V);   // turn off +12V

	reg=0xff;       //make port B as data output
	data=0x00;      //load data on port B

	//if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
	DDRC=0xee ;     //0b 1110 1110  // all outputs except PC0 and PC4 inputs// (PC0,PC4) //RDY and BUTTON as input
	PORTC=0x11;     // pull-up PC0 and PC4   0b 0001 0001
}
//-------------------------------------------------------------------------------
void enterProgMode(void){
	PORTC=0x11;PORTD=0x23;PORTB=0x00;      //enter prog mode
	_delay_ms(dS);                          // stable delay
	PORTD=0x14;
	_delay_ms(dP);                         // pulse delay
	PORTD=0x94;                           //target Active
	_delay_ms(dP);                         // pulse delay
}
//-------------------------------------------------------------------------------
void sendComand(unsigned char cmd){
	PORTC=0x19;PORTD=0x96;PORTB=cmd;       //if pin xtal1 of AVR Dameged *****?????????
	XTALPulse();
}
//-------------------------------------------------------------------------------
void setHfuse(unsigned char fuse){
	PORTC=0x15;                           //set H-fuse bits 
	_delay_ms(dP);                         // pulse delay
	PORTB=fuse;
	XTALPulse();
	PORTC=0x17;
	WRPulse();
}
//-------------------------------------------------------------------------------
void setLfuse(unsigned char fuse){
	PORTC=0x15;                            //set L-fuse bits 
	_delay_ms(dP);                           // pulse delay
	PORTB=fuse;
	XTALPulse();
	PORTC=0x15;
	WRPulse();
}
//-------------------------------------------------------------------------------
void setLock(){                        //set lock_bits
	PORTC=0x15;
	_delay_ms(dP);
	PORTB=0xFF;
	XTALPulse();
	PORTC=0x15;
	WRPulse();
}
//-------------------------------------------------------------------------------
void setExtendedFuse(void){            //set lock_bits
	PORTC=0x15;
	_delay_ms(dP);
	PORTB=0xFF;
	XTALPulse();
	PORTC=0x15;PORTD=0xC4;
	WRPulse();
}
//-------------------------------------------------------------------------------
void erase(){
	PORTC=0x15;
	WRPulse();

}
//-------------------------------------------------------------------------------
void exit(void){
	PORTC=0x11;PORTD=0x23;PORTB=0x00;    //exit
	//delay_ms(dS);                      // stable delay
	beep();
}
//-------------------------------------------------------------------------------
void cmdDown(void){
	beep();
	PORTD |= (1 << LED);
	_delay_ms(dP);
	PORTD &= ~(1 << LED);
	_delay_ms(dP);
}
//-------------------------------------------------------------------------------
// Give XTAL1 a positive pulse.
void XTALPulse(void){
	PORTD=0x9D;
	_delay_ms(dP);                         // pulse delay
	PORTD=0x94;
	_delay_ms(dP);                          // pulse delay
}
//-------------------------------------------------------------------------------
// Give WR a negative pulse for Erase target.
void WRPulse(void){
	PORTD=0x84;               //erase chip
	_delay_ms(dP);             // pulse delay
	PORTD=0x94;
	_delay_ms(dP);
}
//-------------------------------------------------------------------------------
void beep(void){                    // Beeping routine
	int i;
	for(i=0;i<500;i++){       // Loop
		PORTD |= (1 << BUZ);              // Toggle BUZZER
		_delay_ms(50);         // Delay
		PORTD &= ~(1 << BUZ);              // Toggle BUZZER
		_delay_ms(50);         // Delay
	};
}
//-------------------------------------------------------------------------------





/*
 * HV-programmer-ver.0.c
 *
 * Created: 9/21/2023 20:14:41
 * Author : me
 */
//-------------------------------------------------------------------------------
#include <mega8.h>
#include <io.h>
#include <delay.h>

//-------------------------------------------------------------------------------
#define  HFUSE    0xD9    // 0xD9 Default for ATmega8 // 0x99 Default for ATmega16/32
#define  LFUSE    0xE1    // 0xE1 Default for ATmega8 // 0xE1 Default for ATmega16/32
//-------------------------------------------------------------------------------
#define  OE         PORTD.0  // 2   //4     PD0
#define  WR         PORTD.1  // 3   //5     PD1
#define  BS1        PORTD.2  // 4   //6     PD2
#define  XA0        PORTD.3  // 5   //11    PD3
#define  XA1        PORTD.4  // 6   //12    PD4
#define  PAG        PORTD.5  //11   //13    PD5
#define  XTAL1      PORTD.6  //12   //9     PD6
#define  BS2        PORTD.7  //13   //25    PD7

//#define  data       PORTB    // 14-19 ,9,10    // PB0-PB7 //ALL OUTPUTS
//#define  reg        DDRB     //

#define  RED        PORTC.0  //23           PC0      // RED LED
#define  GREEN      PORTC.1  //24           PC1      // GREEN LED
#define  BUZ        PORTC.2  //25           PC2      // BUZZER
#define  Reset12V   PORTC.3  //26   //1     PC3      // low level for !RESET
#define  BUTTON     PINC.4   //27           PC4      // input with pull-up /start by press the button
#define  RDY        PINC.5   //28   //3     PC5      // input with pull-up  / RDY/!BSY signal from target
//-------------------------------------------------------------------------------
void HardwareInit();
void sendcmd(unsigned char command);
void writefuse(unsigned char fuse, char highbyte);
void blink(void);
void beep(void);
//void alert(void);
//-------------------------------------------------------------------------------
void main(void){

    HardwareInit();

        while (1) {
                   // wait for button
                      if(BUTTON==0) {
                            RED=1;
                            Reset12V=1;               //turn off +12V for now
                            delay_ms(100);;           // wait until everything stable
                             // Initialize pins to enter programming mode
                            BS1=0;XA0=0;XA1=0;PAG=0;BS2=0;
                            // Enter programming mode
                            WR=1;OE=1;
                            delay_ms(1);
                            Reset12V=0;               // apply +12V to RESET
                            delay_ms(1);

                            // Program HFUSE
                            sendcmd(0b01000000);
                            writefuse(HFUSE, 1);

                            // Program LFUSE
                            sendcmd(0b01000000);
                            writefuse(LFUSE, 0);

                            delay_ms(1000);            // allow button to be released

                            // Exit programming mode
                            Reset12V=1;                //turn off +12V

                            // Turn off outputs
                            PORTB = 0x00;
                            OE=0;WR=0;BS1=0;XA0=0;XA1=0;PAG=0;BS2=0;
                            beep();
                            blink();
                            RED=0;
                            GREEN=1;
                            }

                            else{

                                 };

            }
}

//-------------------------------------------------------------------------------
 void HardwareInit(){

        DDRD=0xff;      //make port D as output
        PORTD=0x00;     //write data on port D

        DDRB=0xff;      //make port B as output
        PORTB=0x00;     //write data on port B

                        //if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
        DDRC=0x0f ;     //0b 0000 1111  // lower nibble outputs and higher nibble inputs// (PC4,PC5) //RDY and BUTTON as input
        PORTC=0xf0;     // pull-up  higher nibble
}
//-------------------------------------------------------------------------------
void sendcmd(unsigned char command){

        XA1=1;
        XA0=0;BS1=0;

        PORTB = command;

        XTAL1=1;
        delay_ms(1);
        XTAL1=0;
        delay_ms(1);
}
//-------------------------------------------------------------------------------
void writefuse(unsigned char fuse, char highbyte){

        XA1=0;
        delay_ms(1); // aded me
        XA0=1;
        delay_ms(1);

        PORTB = fuse;
        XTAL1=1;
        delay_ms(1);
        XTAL1=0;

        if (highbyte){
            BS1=1;
            }
            else{
                BS1=0;
                };
        WR=1;
        delay_ms(1);
        WR=0;
        delay_ms(100);
}
//-------------------------------------------------------------------------------
void blink(void){

     int i;

         for(i=0;i<7;i++){
            RED=1 ;            // Toggle LED
            delay_ms(100);            // Delay
            RED=0;             // Toggle LED
            delay_ms(100);            // Delay

            };
}
//-------------------------------------------------------------------------------

void beep(void)                    // Beeping routine
{
    int i;
    for(i=0;i<1000;i++){          // Loop
        BUZ=1;                    // Toggle BUZZER
        delay_us(100);            // Delay
        BUZ=0;                    // Toggle BUZZER
        delay_us(100);            // Delay
       };

}
//-------------------------------------------------------------------------------
/*
void alert(void){

        beep();
        delay_ms(1000);
        beep();
        delay_ms(1000);
}  */
//-------------------------------------------------------------------------------
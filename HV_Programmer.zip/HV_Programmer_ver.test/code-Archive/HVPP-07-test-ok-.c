/*
 * HV-programmer-ver.0.c
 *
 * Created: 9/29/2023 20:48:00
 * Author : me
 */
//-------------------------------------------------------------------------------
#include <mega8.h>
#include <io.h>
#include <delay.h>

//-------------------------------------------------------------------------------
#define  HFUSE    0xD9    // 0xD9 Default for ATmega8 // 0x99 Default for ATmega16/32
#define  LFUSE    0xE1    // 0xE1 Default for ATmega8 // 0xE1 Default for ATmega16/32
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
#define  data       PORTB    // 14-19 ,9,10    // PB0-PB7 //ALL OUTPUTS
#define  reg        DDRB     //

                              //MASTER     //SLAVE
#define  LED        PORTD.0  // 2                   PC0      // LED
#define  BUZ        PORTD.1  // 3                   PC1      // BUZZER
#define  OE         PORTD.2  // 4          //4      PD0
#define  XTAL1      PORTD.3  // 5          //9      PD
#define  WR         PORTD.4  // 6          //5      PD1
#define  VCC        PORTD.5  // 11                           //off=1 & on=0 just pnp transistor
#define  BS2        PORTD.6  // 12         //25     PD7
#define  Reset12V   PORTD.7  // 13         //1      PC3      // low level for !RESET   OFF=0 & on=1

#define  RDY        PINC.0   // 23         //3      PC5      // input with pull-up  / RDY/!BSY signal from target
#define  BS1        PORTC.1  // 24         //6      PD2
#define  XA0        PORTC.2  // 25         //11     PD3
#define  XA1        PORTC.3  // 26         //12     PD4
#define  BUTTON     PINC.4   // 27                  PC4      // input with pull-up /start by press the button
#define  PAG        PORTC.5  // 28         //13     PD5
//-------------------------------------------------------------------------------
void settingPorts(void);

//  void blink(char LED);
void beep(void);
//  void WRPulse(void);
//  void XTALPulse(void);

const int  HIGH =1;
const int  LOW  =0;
int dS=500;     // stable delay 1000 ms
int dP=50;      // pulse delay 100   ms


//-------------------------------------------------------------------------------
void main(void){

        settingPorts();
        /*
        beep();
        PORTD=0xff;
        delay_ms(dS);
        PORTC=0xff;PORTD=0x7C;PORTB=0x00;         //test stat
        delay_ms(dS);
        PORTC=0x11;PORTD=0x23;PORTB=0xff;
        delay_ms(dS);
        PORTC=0x11;PORTD=0x23;PORTB=0x00;
        beep();
        */

            while (1) {
                          // wait for button // PORTC.4 as input   // 0b 0001 1111
                          if(BUTTON==LOW){
                                beep();
                                LED=HIGH;

                                PORTC=0x11;PORTD=0x23;PORTB=0x00;     //enter prog mode
                                delay_ms(dS);                          // stable delay
                                PORTD=0x14;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;                          //target Active
                                delay_ms(dP);                         // pulse delay

                                PORTC=0x19;PORTD=0x96;PORTB=0x80;     //cmd for  erase chip
                                PORTD=0x9D;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;
                                delay_ms(dP);                         // pulse delay

                                PORTC=0x15;PORTD=0x84;               //erase chip
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;
                                delay_ms(dS);                          // stable delay

                                PORTC=0x19;PORTD=0x96;PORTB=0x20;    //cmd  for lockbits
                                PORTD=0x9D;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;
                                delay_ms(dP);                         // pulse delay
                                                                     //set lockbits
                                PORTC=0x15;
                                delay_ms(dP);                         // pulse delay
                                PORTB=0xFF;
                                PORTD=0x9D;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;
                                PORTC=0x15;PORTD=0x84;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;                           // stable delay
                                delay_ms(dS);

                                PORTC=0x19;PORTD=0x96;PORTB=0x40;    //cmd for fuse bits
                                PORTD=0x9D;
                                delay_ms(dP);                        // pulse delay
                                PORTD=0x94;
                                delay_ms(dP);                        // pulse delay

                                PORTC=0x19;                           //set H-fuse bits 0xD9 for atmega 8
                                delay_ms(dP);                         // pulse delay
                                PORTB=HFUSE;
                                PORTD=0x9D;
                                delay_ms(dP);                         // pulse delay
                                PORTD=0x94;
                                PORTC=0x17;PORTD=0x84;
                                delay_ms(dP);                           // pulse delay
                                PORTD=0x94;
                                delay_ms(dS);                          // stable delay

                                PORTC=0x19;PORTD=0x96;PORTB=0x40;      //cmd for fuse bits
                                PORTD=0x9D;
                                delay_ms(dP);                           // pulse delay
                                PORTD=0x94;
                                delay_ms(dP);                           // pulse delay

                                PORTC=0x15;                            //set L-fuse bits 0xE1 for atmega 8
                                delay_ms(dP);                           // pulse delay
                                PORTB=LFUSE;
                                PORTD=0x9D;
                                delay_ms(dP);                           // pulse delay
                                PORTD=0x94;
                                PORTC=0x15;PORTD=0x84;
                                delay_ms(dP);                          // pulse delay
                                PORTD=0x94;
                                delay_ms(dS);                          // stable delay

                                PORTC=0x11;PORTD=0x23;PORTB=0x00;    //exit
                                delay_ms(dS);                        // stable delay
                                beep();
                                }

                                    else{
                                         delay_ms(dS);               // stable delay
                                         //XA1=LOW;
                                         XTAL1=HIGH;
                                         };

                }
}
//-------------------------------------------------------------------------------
void settingPorts(void){

            DDRD=0xff;      //make port D as output
            PORTD=0x00;     //write data on port D
            VCC=HIGH;       // turn off +5V
            Reset12V=LOW;   // turn off +12V

            reg=0xff;       //make port B as data output
            data=0x00;      //load data on port B

                            //if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
            DDRC=0xee ;     //0b 1110 1110  // all outputs except PC0 and PC4 inputs// (PC0,PC4) //RDY and BUTTON as input
            PORTC=0x11;     // pull-up PC0 and PC4   0b 0001 0001
}
//-------------------------------------------------------------------------------
/*
// Give XTAL1 a positive pulse.
void XTALPulse(void){
      XTAL1=HIGH;
      delay_ms(100);
      XTAL1=LOW;
      delay_ms(100);
}
//-------------------------------------------------------------------------------
// Give WR a negative pulse for Erase target.
void WRPulse(void){
      WR=LOW;
      delay_ms(100);
      WR=HIGH;
      delay_ms(100);
}
*/
//-------------------------------------------------------------------------------
/*
void blink(char LED){

     int i;
        if(LED==R){
                    //GREEN=LOW;
                    for(i=0;i<3;i++){
                        RED=HIGH ;                // Toggle LED
                        delay_ms(100);            // Delay
                        RED=LOW;                  // Toggle LED
                        delay_ms(100);            // Delay
                    };
        }
            else if(LED==G) {
                    RED=LOW;
                    for(i=0;i<3;i++){
                        //GREEN=HIGH ;           // Toggle LED
                        delay_ms(100);         // Delay
                        //GREEN=LOW;             // Toggle LED
                        delay_ms(100);         // Delay
                    };
            }
}
*/
//-------------------------------------------------------------------------------
void beep(void)                    // Beeping routine
{
        int i;
        for(i=0;i<500;i++){       // Loop
            BUZ=HIGH;              // Toggle BUZZER
            delay_us(100);         // Delay
            BUZ=LOW;               // Toggle BUZZER
            delay_us(100);         // Delay
           };
}
//-------------------------------------------------------------------------------
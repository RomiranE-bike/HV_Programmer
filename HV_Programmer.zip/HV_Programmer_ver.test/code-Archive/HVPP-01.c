/*
 * HV-programmer-ver.0.c
 *
 * Created: 9/21/2023 20:14:41
 * Author : me
 */
//-------------------------------------------------------------------------------
#include <mega8.h>
#include <io.h>
#include <delay.h>

//-------------------------------------------------------------------------------
#define    HFUSE    0xD9    // 0xD9 Default for ATmega8 // 0x99 Default for ATmega16/32
#define    LFUSE    0xE1    // 0xE1 Default for ATmega8 // 0xE1 Default for ATmega16/32
//-------------------------------------------------------------------------------
#define  OE         PORTD.0  // 2        PD0
#define  WR         PORTD.1  // 3        PD1
#define  BS1        PORTD.2  // 4        PD2
#define  XA0        PORTD.3  // 5        PD3
#define  XA1        PORTD.4  // 6        PD4
#define  PAG        PORTD.5  //11        PD5
#define  XTAL1      PORTD.6  //12        PD6
#define  BS2        PORTD.7  //13        PD7

//#define  data       PORTB    // 14-19 ,9,10    // PB0-PB7 //ALL OUTPUTS
//#define  reg        DDRB     //

#define  RED        PORTC.0  //23        PC0      // RED LED
#define  GREEN      PORTC.1  //24        PC1      // GREEN LED
#define  BUZ        PORTC.2  //25        PC2      // BUZZER
#define  Reset12V   PORTC.3  //26        PC3      // low level for !RESET
#define  BUTTON     PINC.4   //27        PC4      // input with pull-up /start by press the button
#define  RDY        PINC.5   //28        PC5      // input with pull-up  / RDY/!BSY signal from target
//-------------------------------------------------------------------------------
void HardwareInit();
void sendcmd(unsigned char command);
void writefuse(unsigned char fuse, char highbyte);
void blink(unsigned char LED);
void beep(void);
void alert(void);
//-------------------------------------------------------------------------------
void main(void)
{
    HardwareInit();
    alert();
    blink(RED);

        while (1) {
        // wait for button

                    if(BUTTON==0) {
                             // Initialize pins to enter programming mode
                            PORTD &= ~(BS1|XA0|XA1|PAG|BS2);
                            // Enter programming mode
                            PORTD |= WR|OE;
                            delay_ms(1);
                            PORTC &= ~(Reset12V);
                            delay_ms(1);

                            // Program HFUSE
                            sendcmd(0b01000000);
                            writefuse(HFUSE, 1);

                            // Program LFUSE
                            sendcmd(0b01000000);
                            writefuse(LFUSE, 0);

                            delay_ms(1000);            // allow button to be released

                            // Exit programming mode
                            PORTC |= Reset12V;

                            // Turn off outputs
                            PORTB = 0x00;
                            PORTD &= ~(OE|WR|BS1|XA0|XA1|PAG|BS2);
                            beep();
                            blink(GREEN);
                            }

                        else{

                             };

        alert();
        blink(RED);
            };
}

//-------------------------------------------------------------------------------
 void HardwareInit()
{

DDRD=0xff;      //make port D as output
PORTD=0x00;     //write data on port D

DDRB=0xff;      //make port B as output
PORTB=0x00;     //write data on port B

               //if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
DDRC    = ~(RDY | BUTTON);                     // all outputs except (PC4,PC5)
PORTC    = (BUTTON);                            // pull-up  PC5
}
//-------------------------------------------------------------------------------
void sendcmd(unsigned char command)
{
    PORTD |= XA1;
    PORTD &= ~(XA0|BS1);

    PORTB = command;

    PORTD |= XTAL1;
    delay_ms(1);
    PORTD &= ~(XTAL1);
    delay_ms(1);
}
//-------------------------------------------------------------------------------
void writefuse(unsigned char fuse, char highbyte)
{
    PORTD &= ~(XA1);
    PORTD |= XA0;
    delay_ms(1);

    PORTB = fuse;
    PORTD |= XTAL1;
    delay_ms(1);
    PORTD &= ~(XTAL1);

    if (highbyte)
    PORTD |= BS1;
    else
    PORTD &= ~(BS1);

    PORTD &= ~(WR);
    delay_ms(1);
    PORTD |= WR;
    delay_ms(100);
}
//-------------------------------------------------------------------------------
void blink(unsigned char LED)
{
     int i;
     for(i=0;i<7;i++)
      {
        PORTC |= LED ;            // Toggle LED
        delay_ms(100);            // Delay
        PORTC &= ~(LED);          // Toggle LED
        delay_ms(100);            // Delay

    };

}
//---------------------------------------------------------------------------------------------------

void beep(void)                   // Beeping routine
{
    int i;
    for(i=0;i<1000;i++)          // Loop
    {
        PORTC |= BUZ;           // Toggle BUZZER
        delay_us(100);          // Delay
        PORTC &= ~(BUZ);        // Toggle BUZZER
        delay_us(100);          // Delay
    };

}
//---------------------------------------------------------------------------------------------------
void alert(void)
{
    beep();
    delay_ms(1000);
    beep();
    delay_ms(1000);
}
//-------------------------------------------------------------------------------
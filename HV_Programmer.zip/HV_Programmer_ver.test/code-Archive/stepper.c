/*******************************************************
This program was created by the
CodeWizardAVR V3.14 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : test-wizard
Version : 1
Date    : 9/10/2023
Author  : me
Company : home
Comments:


Chip type               : ATmega16
Program type            : Application
AVR Core Clock frequency: 4.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 256
*******************************************************/

#include <mega16.h>

void Motor_CCW();
void Motor_CW();

byte CCW[8] = {0x09,0x01,0x03,0x02,0x06,0x04,0x0c,0x08};    //CouterClockWise
byte CW[8] = {0x08,0x0c,0x04,0x06,0x02,0x03,0x01,0x09};     //ClockWise

const int stop_key = 14;  //stop_button connect to Arduino-A0
byte  change_angle=64;    //change the parameter to change the angle of the stepper

void main(void)
{

DDRA=0xff;
PORTA=0x00;
DDRD=0xff;
PORTD=0x00;
DDRC=0xff;
PORTC=0x00;
DDRB=0x00;
PORTB=0xff;



        while (1){
               Motor_CCW();   //make the stepper to anticlockwise rotate
               // Motor_LR(); //make the stepper to clockwise rotate

              };
}



//-----------------------------------------------------------------------------------------------------------------------



void Motor_CCW()    //the steper move 360/64 angle at CouterClockwise
{
  for(int i = 0; i < 8; i++)

    for(int j = 0; j < 8; j++)
    {
     if(digitalRead(stop_key)==0)
      {
      PORTB =0xf0;
      break;
      }
      PORTB = CCW[j];
      delayMicroseconds(1150);
    }
}
//-----------------------------------------------------------------------------------------------------------------------
void Motor_CW()  //the steper move 360/64 angle at Clockwise
{
  for(int i = 0; i < 8; i++)

    for(int j = 0; j < 8; j++)
    {
    if(digitalRead(stop_key)==0)
      {
      PORTB =0xf0;
      break;
      }
      PORTB = CW[j];
      delayMicroseconds(1150);
    }
}
//-----------------------------------------------------------------------------------------------------------------------
void setup()
{
  pinMode(stop_key,INPUT);
  digitalWrite(stop_key,HIGH);
  Serial.begin(57600);
  DDRB=0xff;
  PORTB = 0xf0;
  for(int k=0;k<change_angle;k++)
  {
  Motor_CCW();
  }
 }
//-----------------------------------------------------------------------------------------------------------------------

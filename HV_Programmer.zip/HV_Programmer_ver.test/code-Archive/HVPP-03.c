/*
 * HV-programmer-ver.0.c
 *
 * Created: 9/25/2023 08:40:00
 * Author : me
 */
//-------------------------------------------------------------------------------
#include <mega8.h>
#include <io.h>
#include <delay.h>

//-------------------------------------------------------------------------------
#define  HFUSE    0xD9    // 0xD9 Default for ATmega8 // 0x99 Default for ATmega16/32
#define  LFUSE    0xE1    // 0xE1 Default for ATmega8 // 0xE1 Default for ATmega16/32
//-------------------------------------------------------------------------------
#define  data       PORTB    // 14-19 ,9,10    // PB0-PB7 //ALL OUTPUTS
#define  reg        DDRB     //

#define  OE         PORTD.0  // 2   //4     PD0
#define  WR         PORTD.1  // 3   //5     PD1
#define  BS1        PORTD.2  // 4   //6     PD2
#define  XA0        PORTD.3  // 5   //11    PD3
#define  XA1        PORTD.4  // 6   //12    PD4
#define  PAG        PORTD.5  //11   //13    PD5
#define  XTAL1      PORTD.6  //12   //9     PD6
#define  BS2        PORTD.7  //13   //25    PD7

#define  RED        PORTC.0  //23           PC0      // RED LED
#define  GREEN      PORTC.1  //24           PC1      // GREEN LED
#define  BUZ        PORTC.2  //25           PC2      // BUZZER
#define  Reset12V   PORTC.3  //26   //1     PC3      // low level for !RESET
#define  BUTTON     PINC.4   //27           PC4      // input with pull-up /start by press the button
#define  RDY        PINC.5   //28   //3     PC5      // input with pull-up  / RDY/!BSY signal from target
#define  HIGH       0x01
#define  LOW        0x00
#define  VCC        PORTC.4
//-------------------------------------------------------------------------------
void HardwareInit();
void sendcmd(unsigned char command);
void writefuse(unsigned char fuse, char highbyte);
void SetExtendedFuseBit(unsigned char fuseVal);
void SetLockBit(unsigned char fuseVal);
void LoadDataByte(unsigned char dataVal, unsigned char isByte);
void eraseChip(void);
void blink(unsigned char LED);
void beep(void);
void WRPulse(void);
void XTALPulse(void);
char H;
char L;
//-------------------------------------------------------------------------------
void main(void){

        HardwareInit();

            while (1) {
                          // wait for button // PORTC.4 as input   // 0b 0001 1111
                          if(BUTTON==LOW) {
                                beep();
                                delay_ms(100);
                                DDRC=0x1f;         //0b 0001 1111//reinitial  PORTC.4 as output
                                PORTC=0xe0;         //Shutdown VCC for target//0b 1110 0000
                                eraseChip();
                                writefuse(HFUSE,H);
                                writefuse(LFUSE,L);
                                //SetLockBit(0x???);          //unsigned char fuseVal for default lockbits
                                //SetExtendedFuseBit(0X???)   //unsigned char fuseVal for default extended fusebits
                                // delay_ms(1000);            // wait a while to allow button to be released
                                DDRC=0x0f;         //0b 0000 1111//reinitial  PORTC.4 as input
                                PORTC=0xf0;        //pull-up  higher nibble  0b 1111 0000
                                }

                                else{
                                     blink(GREEN);  //waitting for running Program
                                     };


                }
}
//-------------------------------------------------------------------------------
 void HardwareInit(){

            DDRD=0xff;      //make port D as output
            PORTD=0x00;     //write data on port D

            reg=0xff;      //make port B as data output
            data=0x00;     //load data on port B

                            //if PORTx=0xff enable all pull-ups if PORTx=0x00 then disable pull-ups and make it tri state
            DDRC=0x0f ;     //0b 0000 1111  // lower nibble outputs and higher nibble inputs// (PC4,PC5) //RDY and BUTTON as input
            PORTC=0xf0;     // pull-up  higher nibble  0b 1111 0000
}
//-------------------------------------------------------------------------------
/*
void setDataPinMode(unsigned char value){
  pinMode(PIN_D0, value);     // value mybe input or output
  pinMode(PIN_D1, value);
  pinMode(PIN_D2, value);
  pinMode(PIN_D3, value);
  pinMode(PIN_D4, value);
  pinMode(PIN_D5, value);
  pinMode(PIN_D6, value);
  pinMode(PIN_D7, value);
  delay_us(5);
}
*/
//-------------------------------------------------------------------------------
void EnterProgramMode(){
          //setDataPinMode(INPUT);
          // Initialize pins to enter programming mode
          // Set Prog_enable pins to 0000.
          BS1=LOW; XA0=LOW; XA1=LOW;PAG=LOW;
          // Shutdown VCC and +12V
          VCC=LOW; Reset12V=LOW;
          delay_us(25);
          // Apply 5V to target device.
          VCC=HIGH;
          delay_us(50);
          // Apply +12V to target device.
          Reset12V=HIGH;
          // Wait before giving any parallel programming commands.
          delay_us(500);
          // Enable output and write modes.
          OE=HIGH; WR=HIGH;
          delay_us(50);
          beep();
          blink(RED);
}
//-------------------------------------------------------------------------------
void resetProgramMode(){
          // Power the device down by setting VCC and +12V to low.
          // Exit programming mode
          VCC=LOW; Reset12V=LOW;
          // Reset command bits.
          RDY=HIGH; OE=LOW; WR=LOW; BS1=LOW; BS2=LOW;
          XTAL1=LOW; XA0=LOW; XA1=LOW; PAG=LOW;
            // Turn off all outputs
           data = 0x00;
           beep();
           blink(GREEN);
}
//-------------------------------------------------------------------------------
void sendcmd(unsigned char command){
          // Send command to target AVR
          // Set XA1, XA0 to 10. this enables command loading.
          // Set BS1 to 0.
          // Set controls for command mode
          XA1=HIGH; XA0=LOW; BS1=LOW;
          // load Command
          data = command;
          XTALPulse();  // pulse XTAL to send command to target
}
//-------------------------------------------------------------------------------
void writefuse(unsigned char fuse, char highbyte) {
          EnterProgramMode();
          // Load Command 0100 0000.
          sendcmd(0x40);
          // write high or low fuse to AVR
          // if highbyte = true, then we program HFUSE, otherwise LFUSE
          // Enable data loading
          XA1=LOW; XA0=HIGH;
          delay_ms(1);
          // Write fuse
          data = fuse;    // default  fuse value
          XTALPulse();

                  if(highbyte == H){
                    // program HFUSE
                    BS1=HIGH;
                    }
                          else {
                          //program LFUSE
                          BS1=LOW;
                          WR=LOW;
                          delay_ms(1);
                          WR=HIGH;
                          };

           delay_ms(100);
           resetProgramMode();
    }
//-------------------------------------------------------------------------------
unsigned char IsChipBusy(){
  return ((PORTC & RDY) == RDY) ? 0 : 1;
}
//-------------------------------------------------------------------------------
/*
void EraseChip(){
  // Load command for Chip Erase.
  sendcmd(0x80);
  Delay_ms(1);
  // Give WR a negative pulse for Erase target.
  WRPulse();
  Delay_ms(1);
      // Wait until RDY/BSY goes high.
      while(IsChipBusy() == TRUE){
        Delay_us(250);
      }
} */

void eraseChip(void){
          unsigned char eraseTimeout = 0;
          // Enter device into programming mode.
          EnterProgramMode();
          // Load Command 1000 0000.
          sendcmd(0x80);

          // Give WR a negative pulse.
          WRPulse();
          delay_ms(1);
          // Wait until RDY/BSY goes high.
                  while(eraseTimeout < 250){
                        delay_ms(10);
                        eraseTimeout++;
                        if(RDY == HIGH){
                           eraseTimeout = 0;
                          break;
                        }
                  }

          resetProgramMode();
}
//-------------------------------------------------------------------------------
void SetLockBit(unsigned char fuseVal){
          EnterProgramMode();
          // Load Command 0010 0000.
          sendcmd(0x20);
          delay_ms(1);
          // Load Data Low Byte.
          LoadDataByte(fuseVal, LOW);    //fuse value for defualt lokbits
          // Give WR a negative pulse.
          WRPulse();
          delay_ms(1);
                  // Wait until RDY/BSY goes high.
                  while(IsChipBusy() == 1)
                  {
                    delay_us(250);
                  }
          resetProgramMode();
}
//-------------------------------------------------------------------------------
void SetExtendedFuseBit(unsigned char fuseVal){
          EnterProgramMode();
          // Load Command 0100 0000.
          sendcmd(0x40);
          delay_ms(1);
          // Load Data Low Byte.
          LoadDataByte(fuseVal,LOW);      //fuse value for defualt extended fusebits
          // Set BS1 to 0 and BS2 to 1.
          BS1=LOW; BS2=HIGH;
          // Give WR a negative pulse.
          WRPulse();
          delay_ms(1);
                  // Wait until RDY/BSY goes high.
                  while(IsChipBusy() == 1)
                  {
                    delay_us(250);
                  }
           resetProgramMode();
}
//-------------------------------------------------------------------------------
void LoadDataByte(unsigned char dataVal, unsigned char isByte){
      // Set XA1, XA0 to 01. This enables data loading.
      XA1=HIGH; XA0=LOW;
      // Set BS1 to 1 (this selects high data byte) or 0 (this selects low data byte).
              if(isByte == HIGH){
                     BS1=HIGH;
                }
                        else{
                           BS1=LOW;
                        };
          // Set data value.
          data = dataVal;
          // Give XTAL1 a positive pulse.
          XTALPulse();
}
//-------------------------------------------------------------------------------
// Give XTAL1 a positive pulse.
void XTALPulse(void){
      XTAL1=HIGH;
      delay_ms(1);
      XTAL1=LOW;
      delay_ms(1);
}
//-------------------------------------------------------------------------------
// Give WR a negative pulse for Erase target.
void WRPulse(void){
      WR=LOW;
      delay_ms(1);
      WR=HIGH;
      delay_ms(1);
}
//-------------------------------------------------------------------------------
// Give PAG a positive pulse.
void PagePulse(void){
      PAG=1;
      delay_ms(1);
      PAG=0;
      delay_ms(1);
}
//-------------------------------------------------------------------------------
void blink(unsigned char LED){

     int i;
        if(LED==RED){
         GREEN=LOW;
            for(i=0;i<3;i++){
                RED=HIGH ;                // Toggle LED
                delay_ms(100);            // Delay
                RED=LOW;                  // Toggle LED
                delay_ms(100);            // Delay
            };
        }
            else if(LED==GREEN){
               RED=LOW;
                for(i=0;i<3;i++){
                    GREEN=HIGH ;           // Toggle LED
                    delay_ms(100);         // Delay
                    GREEN=LOW;             // Toggle LED
                    delay_ms(100);         // Delay
                };
            }
}
//-------------------------------------------------------------------------------
void beep(void)                    // Beeping routine
{
        int i;
        for(i=0;i<1000;i++){       // Loop
            BUZ=HIGH;              // Toggle BUZZER
            delay_us(100);         // Delay
            BUZ=LOW;               // Toggle BUZZER
            delay_us(100);         // Delay
           };
}
//-------------------------------------------------------------------------------